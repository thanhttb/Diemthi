<table border="0" cellspacing="2" cellpadding="0" width="100%">

@foreach($scoreboard as $value)
	<tr>
		<td style="TEXT-ALIGN: justify;">
		<LI>
		<a href="{{app_path().'/uploads/'.$value['link']}}" class="newslist" target="_blank"><b>{{$value['name']}}</b></a>
		</td>
	</tr>

@endforeach


</table>