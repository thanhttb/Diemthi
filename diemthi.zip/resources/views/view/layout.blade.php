@extends('view.master')
@section('noidung')
Day la trang layout
@stop