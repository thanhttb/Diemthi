<html>
<head>
<?php 
	include(app_path().'/xcrud/xcrud.php');
	include(app_path().'/xcrud/functions.php');
    echo Xcrud::load_css();
    echo Xcrud::load_js();
 ?>
<title>Kết quả thi học kỳ</title>
<meta http-equiv="Content-Language" content="en-us">
<meta http-equiv="Content-Type" content="text/html" charset="utf-8">
 <link rel="stylesheet" href="content1.css">
</head>

<body>
	<table border="0" cellspacing="1" cellpadding="2" width="100%" class="tableBorder">
		<tr>
		   <th class="tableHeader">Kết quả thi học kỳ</th>
	   </tr>
	
	 <tr>
	 <td> 
	<Select onchange="render()" id="select-hp" name = "lstClass"  size="" ><option value="" > Chọn trong danh sách </option>
	@foreach($classes as $value)
	<option value="{{$value['id']}}">{{$value['name']}}</option>
	@endforeach
	</select>
	</td>
	  </tr>

	<div id="result">
		
	</div>
</body>

<script type="text/javascript">
	
	function render(){
	    $.ajax({url: "{{url('/scoreboard')}}/"+$("#select-hp option:selected").val(), success: function(result){
	        $("#result").html(result);
	    	}
		});
	}

</script>